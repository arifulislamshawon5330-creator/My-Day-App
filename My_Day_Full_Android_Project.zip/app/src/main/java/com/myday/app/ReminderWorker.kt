package com.myday.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.Calendar

class ReminderWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        val now = Calendar.getInstance()
        val prefs = applicationContext.getSharedPreferences("my_day_reminders", Context.MODE_PRIVATE)
        val enabled = prefs.getBoolean("enabled", true)
        val start = prefs.getString("start", "08:00") ?: "08:00"
        val end = prefs.getString("end", "22:00") ?: "22:00"
        val style = prefs.getString("style", "mixed") ?: "mixed"
        val hour = now.get(Calendar.HOUR_OF_DAY)
        val minute = now.get(Calendar.MINUTE)
        val hm = hour * 60 + minute
        val startParts = start.split(":").mapNotNull { it.toIntOrNull() }
        val endParts = end.split(":").mapNotNull { it.toIntOrNull() }
        val startMin = if (startParts.size == 2) startParts[0] * 60 + startParts[1] else 8 * 60
        val endMin = if (endParts.size == 2) endParts[0] * 60 + endParts[1] else 22 * 60
        // WorkManager is inexact: Android may delay delivery to protect battery.
        if (enabled && hm >= startMin && hm <= endMin) {
            val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
                manager.getNotificationChannel(CHANNEL_ID) == null) {
                manager.createNotificationChannel(
                    NotificationChannel(CHANNEL_ID, "My Day reminders", NotificationManager.IMPORTANCE_DEFAULT)
                )
            }
            val index = (hour * 2 + minute / 30 + now.get(Calendar.DAY_OF_YEAR)) % messagesFor(style).size
            val message = messagesFor(style)[index]
            val notification: Notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("My Day")
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .build()
            manager.notify(1000 + hour * 2 + minute / 30, notification)
        }
        return Result.success()
    }

    companion object {
        const val CHANNEL_ID = "my_day_30_minute"
        private val mixedMessages = listOf(
            "Start small. One focused step is progress.",
            "Your future is built by what you do today.",
            "Pause, breathe, and return to your most important task.",
            "Consistency matters more than a perfect day.",
            "Make time for learning, prayer, and rest.",
            "Discipline is choosing what matters over what is easy.",
            "Review your goals and take the next step.",
            "A little progress today is better than waiting for perfect."
        )
        private fun messagesFor(style: String): List<String> = when (style) {
            "study" -> listOf("Time for a focused study session.", "Review one topic or solve a few questions.", "Take the next small step in learning.")
            "tasks" -> listOf("Choose one task and finish it.", "Check your task list and make progress.", "A completed task is progress.")
            "gentle" -> listOf("Take a breath and choose one helpful next step.", "Small progress still counts. Keep going.", "Check in with yourself and continue at your pace.")
            "strict" -> listOf("Less delay, more action. Start now.", "Be accountable: finish one useful task.", "Return to the task you chose.")
            else -> mixedMessages
        }
    }
}
